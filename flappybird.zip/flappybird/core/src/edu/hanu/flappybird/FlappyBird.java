package edu.hanu.flappybird;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Circle;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.audio.Sound;

import java.util.Random;

public class FlappyBird extends ApplicationAdapter {

	SpriteBatch batch;
	Texture background;
	Texture[] birds;
	// animating
	int flapState = 0;

	// moving up & down
	float birdY = 0;
	float velocity = 0;
	float gravity = 2;
	int gameState = 0;

	// pipes
	Texture topTube, bottomTube;
	float gap = 400;
	float maxTubeOffset;
	Random randomGenerator;
	float tubeVelocity = 7;
	int numberOfTubes = 4;
	float[] tubeX = new float[numberOfTubes];
	float[] tubeOffset = new float[numberOfTubes];
	float distanceBetweenTubes;

	// scoring
	BitmapFont font;
	int score = 0;
	int scoringTube = 0 ;

	Circle birdCircle;
	Rectangle topTubeRectangle,bottomTubeRectangle;

	Texture gameover;

	private Sound point;
	private Sound flap;
	private Sound hit;
	private Sound die;
	private Texture start;
	private Music music;



	@Override
	public void create () {
		batch = new SpriteBatch();
		SpriteBatch batch = new SpriteBatch();
		background = new Texture("bg.png");

		//sound//
		flap = Gdx.audio.newSound(Gdx.files.internal("flap.mp3"));
		hit = Gdx.audio.newSound(Gdx.files.internal("hit.mp3"));
		die = Gdx.audio.newSound(Gdx.files.internal("die.mp3"));
		point = Gdx.audio.newSound(Gdx.files.internal("point.mp3"));
		music =Gdx.audio.newMusic(Gdx.files.internal("game.mp3"));

		music.setLooping(true);
		music.setVolume(1f);
		music.play();

		// animating//
		birds = new Texture[2];
		birds[0] = new Texture("bird.png");
		birds[1] = new Texture("bird2.png");

		// pipes
		topTube = new Texture("toptube.png");
		bottomTube = new Texture("bottomtube.png");
		maxTubeOffset = Gdx.graphics.getHeight()/2 - gap /2 - 100;
		randomGenerator = new Random();

		// setups
		distanceBetweenTubes = Gdx.graphics.getWidth() * 3/4;
		birdY = Gdx.graphics.getHeight()/2-birds[flapState].getHeight()/2;
		for (int i = 0; i < numberOfTubes; i++) {
			tubeOffset[i] = (randomGenerator.nextFloat() - 0.5f) * maxTubeOffset;
			tubeX[i] = Gdx.graphics.getWidth()/2 - topTube.getWidth()/2 + i * distanceBetweenTubes + Gdx.graphics.getWidth();
		}

		//
		BitmapFont.BitmapFontData fontData = new BitmapFont.BitmapFontData();
		font = new BitmapFont();
		font.setColor(Color.WHITE);
		font.getData().setScale(10);
		fontData.getGlyph('A');

		//      Set the scale of the sprite


		// shapes
		//shapeRenderer = new ShapeRenderer();
		birdCircle = new Circle();
		topTubeRectangle = new Rectangle();
		bottomTubeRectangle = new Rectangle();

		//gameover
		gameover = new Texture("gameover.png");

		// Create a sprite from the texture
		start = new Texture("start.png");

	}

	@Override
	public void render () {
		batch.begin();
		batch.draw(background, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());

		// the game states
		if (gameState == 1) { // game playing

			// moving up & down
			if (Gdx.input.justTouched()) {
				velocity = -30;
				flap.play(3f);
			}

			// pipes
			for (int i = 0; i < numberOfTubes; i++) {
				// replace tube
				if (tubeX[i] < -topTube.getWidth()) {
					tubeX[i] += numberOfTubes * distanceBetweenTubes;
				} else {
					tubeX[i] -= tubeVelocity;
				}

				batch.draw(topTube, tubeX[i], Gdx.graphics.getHeight() / 2 + gap / 2 + tubeOffset[i]);
				batch.draw(bottomTube, tubeX[i], Gdx.graphics.getHeight() / 2 - gap / 2 - bottomTube.getHeight() + tubeOffset[i]);
			}


			if (birdY > 0 || velocity < 0) {
				velocity += gravity;
				birdY -= velocity;
			}




			if (tubeX[scoringTube] < Gdx.graphics.getWidth() / 2) {
				score++;
				scoringTube++;
				if (scoringTube == numberOfTubes) {
					scoringTube = 0;
				}
				point.play(3f);
			}




			//  shapes
			//	shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
			//	shapeRenderer.setColor(Color.RED);
			// bird circle

			birdCircle.set(Gdx.graphics.getWidth()/2, birdY + birds[flapState].getHeight()/2, birds[flapState].getWidth()/2);
			//shapeRenderer.circle(birdCircle.x, birdCircle.y, birdCircle.radius);
			//scoring tube rectangle
			topTubeRectangle.set(tubeX[scoringTube], Gdx.graphics.getHeight()/2+gap/2 + tubeOffset[scoringTube], topTube.getWidth(), topTube.getHeight());
			bottomTubeRectangle.set(tubeX[scoringTube], Gdx.graphics.getHeight()/2 - gap/2 - bottomTube.getHeight() + tubeOffset[scoringTube], bottomTube.getWidth(), bottomTube.getHeight());
			//shapeRenderer.rect(topTubeRectangle.x, topTubeRectangle.y, topTubeRectangle.width, topTubeRectangle.height);
			//shapeRenderer.rect(bottomTubeRectangle.x, bottomTubeRectangle.y, bottomTubeRectangle.width, bottomTubeRectangle.height);
			//shapeRenderer.end();

			// TODO: collision detection
			if(Intersector.overlaps(birdCircle, topTubeRectangle)||Intersector.overlaps(birdCircle, bottomTubeRectangle)) {
				gameState =3;
				hit.play(1f);
				die.play(1f);
			}
		} else if(gameState ==3){


			batch.draw(gameover, Gdx.graphics.getWidth()/2-gameover.getWidth()/2,Gdx.graphics.getHeight()/2-gameover.getHeight()/2);
			batch.draw(start,Gdx.graphics.getWidth()/2-start.getWidth()/2,Gdx.graphics.getHeight()/4-start.getHeight()/4);

			String scoreString = "Score: " + score;
			font.draw(batch, scoreString, Gdx.graphics.getWidth() / 2 -250, Gdx.graphics.getHeight() / 2 + 250);

			if (Gdx.input.justTouched()) {

				birdY = Gdx.graphics.getHeight()/2-birds[flapState].getHeight()/2;

				gameState = 0;
				for (int i = 0; i < numberOfTubes; i++) {
					tubeOffset[i] = (randomGenerator.nextFloat() - 0.5f) * maxTubeOffset;
					tubeX[i] = Gdx.graphics.getWidth()/2 - topTube.getWidth()/2 + i * distanceBetweenTubes + Gdx.graphics.getWidth();
				}
				score = 0;
				scoringTube = 0;

			}
		}
		else { // game start
			if (Gdx.input.justTouched()) {
				gameState = 1;
			}
		}

		// animating
		if (flapState == 0) {
			flapState = 1;
		} else {
			flapState = 0;
		}
		batch.draw(birds[flapState], Gdx.graphics.getWidth()/2-birds[flapState].getWidth()/2, birdY);

		// TODO: scoring
		font.draw(batch, score+"", 100, 200);
		batch.end();
	}

	public void dispose () {
		batch.dispose();
		background.dispose();
		super.dispose();
		die.dispose();
		point.dispose();
		flap.dispose();
		hit.dispose();
		music.dispose();
	}
}
